﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace AttendanceMan
{
    public partial class frmLogin : Form
    {
        private double count = 0;
        private Button btnLogin;
        private Button btnExit;
        private Button btnReset;
        private TextBox txtUser;
        private TextBox txtPass;
        private Label label1;
        private Label labelUsername;
        private Label labelPassword;
        private GroupBox groupBoxLogin;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.btnLogin = new Button();
            this.btnExit = new Button();
            this.btnReset = new Button();
            this.txtUser = new TextBox();
            this.txtPass = new TextBox();
            this.label1 = new Label();
            this.labelUsername = new Label();
            this.labelPassword = new Label();
            this.groupBoxLogin = new GroupBox();

            // 
            // Form Properties
            // 
            this.ClientSize = new Size(400, 300);
            this.BackColor = Color.Black; // Black background for the form
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // 
            // groupBoxLogin
            // 
            this.groupBoxLogin.Location = new Point(50, 20);
            this.groupBoxLogin.Size = new Size(300, 220); // Adjusted size
            this.groupBoxLogin.BackColor = Color.Black; // Black for GroupBox
            this.groupBoxLogin.ForeColor = Color.White; // White text for GroupBox
            this.groupBoxLogin.Text = "Hifza's Login Page";

            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new Font("Arial", 16, FontStyle.Bold);
            this.label1.Location = new Point(80, 30);
            this.label1.ForeColor = Color.White; // White text
            this.label1.Text = "Login Form";

            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.ForeColor = Color.White; // White text
            this.labelUsername.Location = new Point(20, 70);
            this.labelUsername.Text = "Username:";

            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.ForeColor = Color.White; // White text
            this.labelPassword.Location = new Point(20, 120);
            this.labelPassword.Text = "Password:";

            // 
            // txtUser
            // 
            this.txtUser.Location = new Point(100, 67); // Positioned directly in front of Username label
            this.txtUser.Size = new Size(175, 20);
            this.txtUser.Font = new Font("Arial", 10);
            this.txtUser.BorderStyle = BorderStyle.FixedSingle;
            this.txtUser.BackColor = Color.Gray; // Gray for textbox
            this.txtUser.ForeColor = Color.White; // White text

            // 
            // txtPass
            // 
            this.txtPass.Location = new Point(100, 117); // Positioned directly in front of Password label
            this.txtPass.Size = new Size(175, 20);
            this.txtPass.Font = new Font("Arial", 10);
            this.txtPass.BorderStyle = BorderStyle.FixedSingle;
            this.txtPass.BackColor = Color.Gray; // Gray for textbox
            this.txtPass.ForeColor = Color.White; // White text
            this.txtPass.UseSystemPasswordChar = true;

            // 
            // btnLogin
            // 
            this.btnLogin.Location = new Point(30, 160); // Adjusted position
            this.btnLogin.Size = new Size(75, 30);
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.BackColor = Color.White; // White button
            this.btnLogin.ForeColor = Color.Black; // Black text
            this.btnLogin.FlatStyle = FlatStyle.Flat;
            this.btnLogin.Click += new EventHandler(this.btnLogin_Click);

            // 
            // btnExit
            // 
            this.btnExit.Location = new Point(110, 160); // Adjusted position
            this.btnExit.Size = new Size(75, 30);
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.BackColor = Color.White; // White button
            this.btnExit.ForeColor = Color.Black; // Black text
            this.btnExit.FlatStyle = FlatStyle.Flat;
            this.btnExit.Click += new EventHandler(this.btnExit_Click);

            // 
            // btnReset
            // 
            this.btnReset.Location = new Point(190, 160); // Adjusted position
            this.btnReset.Size = new Size(75, 30);
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.BackColor = Color.Gray; // Gray button
            this.btnReset.ForeColor = Color.White; // White text
            this.btnReset.FlatStyle = FlatStyle.Flat;
            this.btnReset.Click += new EventHandler(this.btnReset_Click);

            // 
            // Add Controls to the GroupBox
            // 
            this.groupBoxLogin.Controls.Add(this.label1);
            this.groupBoxLogin.Controls.Add(this.labelUsername);
            this.groupBoxLogin.Controls.Add(this.labelPassword);
            this.groupBoxLogin.Controls.Add(this.txtUser);
            this.groupBoxLogin.Controls.Add(this.txtPass);
            this.groupBoxLogin.Controls.Add(this.btnLogin);
            this.groupBoxLogin.Controls.Add(this.btnExit);
            this.groupBoxLogin.Controls.Add(this.btnReset);

            // 
            // Add GroupBox to the Form
            // 
            this.Controls.Add(this.groupBoxLogin);
            this.Load += new EventHandler(this.frmLogin_Load);
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogin; // Set the login button as the default button
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtPass.Clear();
            txtUser.Clear();
            txtUser.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user = "hifza"; // Updated username
            string pass = "22011556-060"; // Keep the same password

            if (txtUser.Text == user && txtPass.Text == pass)
            {
                this.Hide();
                frmWelcome welcomeForm = new frmWelcome(); // Instantiate the welcome form
                welcomeForm.Show();
            }
            else
            {
                count++;
                double maxcount = 3;
                double remain = maxcount - count;
                MessageBox.Show("Wrong username or password. " + remain + " tries left");

                txtPass.Clear();
                txtUser.Clear();
                txtUser.Focus();

                if (count == maxcount)
                {
                    MessageBox.Show("Max try exceeded.");
                    Application.Exit();
                }
            }
        }
    }
}
