using System;
using System.Data;
using System.Windows.Forms;

public partial class HifsaZafarForm : Form // Correct class name
{
    DataTable dt = new DataTable();

    public HifsaZafarForm() // Correct constructor name
    {
        InitializeComponent(); // Initialize all UI components
        CreateNewRow(); // Initialize columns when the form loads
    }

    public void CreateNewRow()
    {
        if (dt.Columns.Count == 0) // Create columns only once
        {
            dt.Columns.Add(new DataColumn("Course Code", typeof(string))); // Correct column name
            dt.Columns.Add(new DataColumn("Course Title", typeof(string))); // Correct column name
            dt.Columns.Add(new DataColumn("Obtained Marks", typeof(int))); // Correct column name
            dt.Columns.Add(new DataColumn("Grade", typeof(string))); // Correct column name
            dt.Columns.Add(new DataColumn("Status", typeof(string))); // Correct column name
        }
    }

    public void AddRowToDataTable()
    {
        // Add a new row with user inputs
        dt.Rows.Add(
            txt_courseCode.Text, // Course code input
            txt_courseTitle.Text, // Course title input
            Convert.ToInt32(txt_obtainedMarks.Text), // Obtained marks input
            txt_grade.Text, // Grade input
            txt_status.Text // Status input
        );
        dataGridView1.DataSource = dt; // Update DataGridView with the new data
    }

    private void btn_add_Click(object sender, EventArgs e)
    {
        AddRowToDataTable(); // Call method to add a new row when the button is clicked
    }
}
