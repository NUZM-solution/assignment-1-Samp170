using System;
using System.Windows.Forms; // Keep this for Windows Forms functionality

namespace HizasTable
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            System.Windows.Forms.Application.EnableVisualStyles(); // Fully qualified name
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false); // Fully qualified name
            System.Windows.Forms.Application.Run(new HifsaZafarForm()); // Fully qualified name
        }
    }
}
